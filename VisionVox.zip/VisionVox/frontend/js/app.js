// VisionVox Dummy System Simulation

const obstacles = ["Detected", "Clear"];
const directions = ["Front", "Left", "Right"];
const gestures = ["HELP", "STOP", "YES", "NO", "THANK YOU"];
const audioStates = ["Speaking", "Idle"];

// Get elements
const obstacleEl = document.getElementById("obstacle");
const directionEl = document.getElementById("direction");
const gestureEl = document.getElementById("gesture");
const audioEl = document.getElementById("audio");
const cameraEl = document.getElementById("cameraStatus");

setInterval(() => {

  // Random obstacle
  const obstacle = obstacles[Math.floor(Math.random() * obstacles.length)];
  obstacleEl.textContent = obstacle;
  obstacleEl.className = obstacle === "Detected" ? "danger" : "safe";

  // Random direction
  const direction = directions[Math.floor(Math.random() * directions.length)];
  directionEl.textContent = direction;
  directionEl.className = "warning";

  // Random gesture
  const gesture = gestures[Math.floor(Math.random() * gestures.length)];
  gestureEl.textContent = gesture;

  // Audio status
  const audio = audioStates[Math.floor(Math.random() * audioStates.length)];
  audioEl.textContent = audio;
  audioEl.className = audio === "Speaking" ? "safe" : "warning";

  // Camera pulse text
  cameraEl.textContent = "Live Camera Stream • Processing";

  console.log("VisionVox system running...");

}, 2000);
