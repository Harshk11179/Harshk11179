setInterval(() => {
  console.log("VisionVox system running...");
}, 1000);
